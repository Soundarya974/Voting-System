<?php

include_once('adminLogin.php');

header('Location: adminDashboard.html');

?>
